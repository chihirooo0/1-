import requests
import nmap
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

API_URL = "http://localhost:8000/api" 

def get_vulnerabilities_from_api():
    """Получение списка уязвимостей из API."""
    try:
        response = requests.get(f"{API_URL}/vulnerabilities/")
        response.raise_for_status() 
        return response.json()
    except requests.RequestException as e:
        logging.error(f"Ошибка при получении уязвимостей из API: {e}")
        return []

def scan_host(ip_address, vulnerabilities):
    """Сканирование хоста на наличие уязвимостей."""
    scanner = nmap.PortScanner()
    try:
        scan_result = scanner.scan(ip_address, arguments='-sV') 
    except nmap.PortScannerError as e:
        logging.error(f"Ошибка при сканировании {ip_address}: {e}")
        return []

    results = []
    for port, service_data in scan_result.get('scan', {}).get(ip_address, {}).get('tcp', {}).items():
        service_name = service_data.get('name')
        for vuln in vulnerabilities:
            if service_name and service_name in vuln.get('code_snippet', ''):
                results.append({
                    'port': port,
                    'service': service_name,
                    'vulnerability': vuln['title'],
                    'source_url': vuln.get('source_url', 'Не указано'),
                })
    return results

def parse_and_display_data():
    """Парсинг и вывод данных из API."""
    vulnerabilities = get_vulnerabilities_from_api()
    if not vulnerabilities:
        logging.info("Уязвимости не найдены в API.")
        return

    logging.info("Список уязвимостей, полученных из API:")
    for vuln in vulnerabilities:
        logging.info(f"Заголовок: {vuln['title']}")
        logging.info(f"Описание: {vuln.get('description', 'Не указано')}")
        logging.info(f"Источник: {vuln.get('source_url', 'Не указано')}")
        logging.info("-" * 50)

def main():
    command = input("Введите команду (scan/parse): ").strip().lower()

    if command == "scan":
        vulnerabilities = get_vulnerabilities_from_api()
        if not vulnerabilities:
            logging.info("Не удалось загрузить уязвимости из API.")
            return

        test_ip = input("Введите IP-адрес для сканирования: ")

        logging.info(f"Сканируем {test_ip} на уязвимости...")
        results = scan_host(test_ip, vulnerabilities)

        if results:
            logging.info("Найдены уязвимости:")
            for res in results:
                logging.info(f"Порт: {res['port']}, Сервис: {res['service']}, Уязвимость: {res['vulnerability']}, Ссылка: {res['source_url']}")
        else:
            logging.info("Уязвимости не найдены.")

    elif command == "parse":
        parse_and_display_data()

    else:
        logging.info("Неизвестная команда. Пожалуйста, используйте 'scan' или 'parse'.")

if __name__ == "__main__":
    main()
