from django.contrib import admin
from .models import Vulnerability

@admin.register(Vulnerability)
class VulnerabilityAdmin(admin.ModelAdmin):
    list_display = ('exploit_id', 'title', 'date', 'source_url')  
    search_fields = ('title', 'exploit_id')  
    list_filter = ('date',)  
    ordering = ('-date',)  
    list_per_page = 20 
