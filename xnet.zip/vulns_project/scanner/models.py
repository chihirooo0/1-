from django.db import models

class Vulnerability(models.Model):
    exploit_id = models.CharField(max_length=255) 
    title = models.CharField(max_length=255) 
    date = models.CharField(max_length=255, blank=True)
    source_url = models.URLField(blank=True)
    code_snippet = models.TextField(blank=True)

    def __str__(self):
        return self.title
