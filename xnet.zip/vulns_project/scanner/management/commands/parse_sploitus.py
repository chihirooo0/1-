from django.core.management.base import BaseCommand
from scanner.sploitus_parser import run_parser

class Command(BaseCommand):
    help = 'Parse data from sploitus'

    def handle(self, *args, **kwargs):
        run_parser()
