import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from .models import Vulnerability
from .serializers import VulnerabilitySerializer

def run_parser():
    debug = False

    options = Options()
    options.headless = False  
    gecko_path = "/Users/n_vladik/Desktop/vulns_project/geckodriver" 

    service = Service(gecko_path)
    driver = webdriver.Firefox(service=service, options=options)

    try:
        driver.get("https://sploitus.com/?query=POC#exploits")
        WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, "span.label:nth-child(2)")))

        try:
            sort_by_date_element = driver.find_element(By.CSS_SELECTOR, "span.label:nth-child(2)")
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", sort_by_date_element)
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "span.label:nth-child(2)")))

            sort_by_date_element.click()
            time.sleep(2)
        except Exception as e:
            print(f"Error clicking sort element: {e}")

        for n in range(1, 11):
            try:
                title_xpath = f"/html/body/div[1]/div/div[2]/div[{n}]/div/label/div[2]/div[1]"
                title_element = driver.find_element(By.XPATH, title_xpath)
                title = title_element.text

                date_xpath = f"/html/body/div[1]/div/div[2]/div[{n}]/div/label/div[2]/div[2]"
                date = driver.find_element(By.XPATH, date_xpath).text if EC.presence_of_element_located(
                    (By.XPATH, date_xpath)) else "N/A"

                label_xpath = f"/html/body/div[1]/div/div[2]/div[{n}]/div/label"
                label_element = driver.find_element(By.XPATH, label_xpath)
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", label_element)
                label_element.click()
                time.sleep(1)

                expanded_section_xpath = f"/html/body/div[1]/div/div[2]/div[{n}]/div/div"
                expanded_section = driver.find_element(By.XPATH, expanded_section_xpath)
                source_link = "N/A"
                try:
                    source_button = expanded_section.find_element(By.CSS_SELECTOR, ".btn[data-action='origin']")
                    exploit_id = source_button.get_attribute("data-id")
                    source_button.click()

                    original_window = driver.current_window_handle
                    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(2))

                    for handle in driver.window_handles:
                        if handle != original_window:
                            driver.switch_to.window(handle)
                            break

                    WebDriverWait(driver, 15).until(lambda d: d.current_url != "about:blank")
                    source_link = driver.current_url

                    driver.close()
                    driver.switch_to.window(original_window)

                except Exception as e:
                    print(f"Error handling source button: {e}")

                try:
                    code_element = expanded_section.find_element(By.CSS_SELECTOR,
                                                                 "div.col-12.centered pre.centered.code code")
                    code_snippet = code_element.text
                except Exception:
                    code_snippet = "N/A"

                if debug:
                    print(f"Item {n}:")
                    print(f"ID: {exploit_id}")
                    print(f"Title: {title}")
                    print(f"Date: {date}")
                    print(f"Source Link: {source_link}")
                    print(f"Code Snippet: {code_snippet[:50]}...{code_snippet[-50:]}\n")
                else:
                    print(f"Inserting into DB - Title: {title}, Source Link: {source_link}")

                    if not Vulnerability.objects.filter(exploit_id=exploit_id).exists():
                        serializer = VulnerabilitySerializer(data={
                            'exploit_id': exploit_id,
                            'title': title,
                            'date': date,
                            'source_url': source_link,
                            'code_snippet': code_snippet
                        })
                        if serializer.is_valid():
                            serializer.save()
                        else:
                            print(f"Error: {serializer.errors}")
                    else:
                        print(f"Уязвимость с ID {exploit_id} уже существует в базе.")

            except Exception as e:
                print(f"Error processing item {n}: {e}")

    finally:
        driver.quit()
